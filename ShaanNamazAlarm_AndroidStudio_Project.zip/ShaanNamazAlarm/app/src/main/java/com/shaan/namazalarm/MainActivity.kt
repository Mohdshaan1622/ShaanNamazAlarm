package com.shaan.namazalarm

import android.app.*
import android.content.*
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.util.*

class MainActivity : Activity() {
    private val names = listOf("Fajr", "Zuhr", "Asr", "Maghrib", "Isha")
    private val prefs by lazy { getSharedPreferences("times", MODE_PRIVATE) }
    private val sounds by lazy { getSharedPreferences("sounds", MODE_PRIVATE) }
    private lateinit var container: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 20)
        }
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 28)
            setBackgroundColor(android.graphics.Color.rgb(8,42,32))
        }
        scroll.addView(container)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "🕌  Shaan Namaz Alarm"
            textSize = 27f
            setTextColor(android.graphics.Color.rgb(212,175,55))
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 28)
        }
        container.addView(title)

        names.forEach { addPrayer(it) }
        addFriday()
        addSettings()
    }

    private fun addPrayer(name: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            background = resources.getDrawable(com.shaan.namazalarm.R.drawable.card_bg, theme)
        }
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
        }
        val label = TextView(this).apply {
            text = name
            textSize = 20f
            setTextColor(android.graphics.Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        val time = prefs.getString(name, "Set Time") ?: "Set Time"
        val timeButton = Button(this).apply {
            text = time
            setOnClickListener { chooseTime(name, this) }
        }
        row.addView(timeButton)
        card.addView(row)
        val soundButton = Button(this).apply {
            text = "🔊 Alarm Sound"
            setOnClickListener { chooseSound(name) }
        }
        card.addView(soundButton)
        container.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
    }

    private fun addFriday() {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            background = resources.getDrawable(com.shaan.namazalarm.R.drawable.card_bg, theme)
        }
        val label = TextView(this).apply {
            text = "🕌 Friday — Jummah"
            textSize = 20f
            setTextColor(android.graphics.Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        card.addView(label)
        val row = LinearLayout(this)
        val jummah = Button(this).apply {
            text = prefs.getString("Jummah", "Set Jummah Time")
            setOnClickListener { chooseTime("Jummah", this) }
        }
        row.addView(jummah, LinearLayout.LayoutParams(0, -2, 1f))
        val sound = Button(this).apply {
            text = "🔊 Jummah Sound"
            setOnClickListener { chooseSound("Jummah") }
        }
        row.addView(sound)
        card.addView(row)
        container.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
    }

    private fun addSettings() {
        val dnd = Button(this).apply {
            text = "🌙 DND / Alarm Settings"
            setOnClickListener {
                try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)) }
                catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
        }
        container.addView(dnd)
    }

    private fun chooseTime(name: String, button: Button) {
        val now = Calendar.getInstance()
        TimePickerDialog(this, { _, h, m ->
            val value = String.format(Locale.getDefault(), "%02d:%02d", h, m)
            prefs.edit().putString(name, value).apply()
            button.text = value
            AlarmScheduler.schedule(this, name, h, m)
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show()
    }

    private fun chooseSound(name: String) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "audio/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, 1000 + name.hashCode().and(0x3ff))
    }
}
